<!-- BLOG ENTRY (POST) -->

<?php get_header(); ?>
 
<div class="container my-5">
	<div class="row ">
	   <div class="col-md-12">    
	      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	      	<div class="page-post">
	      		<div class="page-post text-center">
	      			<img class="post-img" src="<?php the_post_thumbnail_url('medium') ?>" alt="">
	      		</div>
		<div class="row ">				
			<div class="col-md-12">
		         <h1 class="my-3 text-center"><?php the_title(); ?></h1>
		         <hr>
		         <div class="entry my-5">
		            <p class="blog-text"><?php the_content(); ?></p>
		         </div>
	     	</div>
	     	<?php if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif; ?>
       	</div>
	      <?php endwhile; endif; ?>
       </div>

	</div>
</div>
</div>
 
	
<?php get_footer(); ?>


