<!-- CONTENT PAGE (PAGES) -->

<?php get_header(); ?>
 
   <div class="container my-5">
       
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
         <h2 class="my-5"><?php the_title(); ?></h2>
         <div class="entry">
            <p><?php the_content(); ?></p>
         </div>
      <?php endwhile; endif; ?>
             
   </div>
 
<?php get_footer(); ?>