<?php get_header(); ?>
<?php
if ( have_posts() ) {
        while ( have_posts() ) {
                the_post();
                $categories=get_the_category();
                $separator=', ';
                $output="";
               

         ?>
<div class="container portfolio my-5">
  <div class="row">
    <div class="col-md-12">
      <div class="heading">       
        <img src="https://image.ibb.co/cbCMvA/logo.png" />
      </div>
    </div>  
  </div>
  <div class="bio-info">
    <div class="row">
      <div class="col-md-6">
        <div class="row">
          <div class="col-md-12">
            <div class="bio-image">
              <img class="img-bio" src="<?php the_post_thumbnail_url("small") ?>" alt="image" />
            </div>      
          </div>
        </div>  
      </div>
      <div class="col-md-6">
        <div class="bio-content">
          <h1><?php the_title(); ?></h1>
          <p><?php the_content(); ?></p>
        </div>
      </div>
    </div>  
       <?php        //
        } // end while
} // end if
?>
  </div>
</div>

<?php get_footer(); ?>