<?php
/**
 * Template Name: Template 1
 */
?>
<?php get_header(); ?>
 

	<div class="container my-5">



<div class="row">
					<div class="col-md-12">
						<div class="section-title mb-4">
							<h2>Recent Posts</h2>
							<hr>
						</div>
					</div>

<?php
if ( have_posts() ) {
        while ( have_posts() ) {
                the_post();
                $categories=get_the_category();
                $separator=', ';
                $output="";
               

         ?>
					<!-- post -->
					<div class="col-md-6">
						<div class="post">
							<a class="post-img" href="<?php the_permalink(); ?>"><img src="<?php echo the_post_thumbnail_url($size = 'medium'); ?>" alt=""></a>
							<div class="post-body">
								<div class="post-meta">
									<?php 

										foreach ($categories as $category) {
											$output.=$category->cat_name.$separator;
										}
											$category=trim($output,$separator);

									 ?>
									<a class="post-category cat-1" href="<?php the_permalink(); ?>"><?php echo $category ?></a>
									<span class="post-date"><?php the_time('F jS, Y') ?></span>
								</div>
								<h3 class="post-title"><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h3>
								<div class="content">
									<p><?php the_excerpt(); ?></p>
								</div>
							</div>
						</div>
					</div>
					<!-- /post -->
	        <?php        //
        } // end while
} // end if
?>
</div>
</div>

<?php get_footer(); ?>