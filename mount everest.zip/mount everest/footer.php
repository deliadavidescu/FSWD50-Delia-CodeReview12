   <footer class="blog-footer bg-dark text-center text-light">
     <p>&copy; <?php echo Date('Y'); ?> <?php bloginfo('name'); ?></p>
     <p>
       <a href="#">Back to top</a>
     </p>
   </footer>

<?php wp_footer(); ?>

    </footer>
</body>
</html>