<?php get_header(); ?>
index.
<div class="fluid-container bg-light mt-5">
  <h1 class="pl-5">Recent Blog Posts</h1>
</div>
<div class="fluid-container">
  <div class="row mx-2">
    <div class="col-lg-9">
      <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>  <!-- loop through the posts -->
    <div class="col-lg-4 blog-posts my-5">
      <img class="blog-img" src="<?php the_post_thumbnail_url("small") ?>" alt="">
      <p class="category">Eastern Europe</p>
      <a class="title" href="<?php the_permalink() ?>"><h2><?php the_title(); ?></h2></a>
      <hr>
      <p class="content"><?php the_excerpt(); ?></p>
      <p class="date"><?php the_time('F jS, Y') ?></p>
    </div><!--Post -->
    <?php endwhile;  endif;?>
    </div>
   <div class="col-lg-3">
     <?php get_sidebar( 'primary' ); ?>
   </div>
  </div>
</div>
<?php get_footer(); ?>